﻿namespace Potatores
{
    partial class ventana
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl_vega = new System.Windows.Forms.Label();
            this.lbl_adri = new System.Windows.Forms.Label();
            this.lbl_harillo = new System.Windows.Forms.Label();
            this.lbl_Damian = new System.Windows.Forms.Label();
            this.lbl_juanra = new System.Windows.Forms.Label();
            this.vida_juanra = new System.Windows.Forms.ProgressBar();
            this.vida_vega = new System.Windows.Forms.ProgressBar();
            this.vida_adri = new System.Windows.Forms.ProgressBar();
            this.vida_damian = new System.Windows.Forms.ProgressBar();
            this.vida_harillo = new System.Windows.Forms.ProgressBar();
            this.lbl_evento = new System.Windows.Forms.Label();
            this.txt_eleccion = new System.Windows.Forms.TextBox();
            this.btn_ok = new System.Windows.Forms.Button();
            this.img_harillo = new System.Windows.Forms.PictureBox();
            this.img_juanra = new System.Windows.Forms.PictureBox();
            this.img_vega = new System.Windows.Forms.PictureBox();
            this.img_damian = new System.Windows.Forms.PictureBox();
            this.img_adri = new System.Windows.Forms.PictureBox();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.img_harillo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_juanra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_vega)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_damian)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_adri)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_vega
            // 
            this.lbl_vega.AutoSize = true;
            this.lbl_vega.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_vega.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_vega.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_vega.Location = new System.Drawing.Point(1048, 229);
            this.lbl_vega.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_vega.Name = "lbl_vega";
            this.lbl_vega.Size = new System.Drawing.Size(75, 31);
            this.lbl_vega.TabIndex = 5;
            this.lbl_vega.Text = "Vega";
            // 
            // lbl_adri
            // 
            this.lbl_adri.AutoSize = true;
            this.lbl_adri.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_adri.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_adri.Location = new System.Drawing.Point(512, 437);
            this.lbl_adri.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_adri.Name = "lbl_adri";
            this.lbl_adri.Size = new System.Drawing.Size(60, 29);
            this.lbl_adri.TabIndex = 6;
            this.lbl_adri.Text = "Adri";
            // 
            // lbl_harillo
            // 
            this.lbl_harillo.AutoSize = true;
            this.lbl_harillo.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbl_harillo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_harillo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_harillo.Location = new System.Drawing.Point(1673, 437);
            this.lbl_harillo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_harillo.Name = "lbl_harillo";
            this.lbl_harillo.Size = new System.Drawing.Size(92, 31);
            this.lbl_harillo.TabIndex = 7;
            this.lbl_harillo.Text = "Harillo";
            // 
            // lbl_Damian
            // 
            this.lbl_Damian.AutoSize = true;
            this.lbl_Damian.BackColor = System.Drawing.Color.Gray;
            this.lbl_Damian.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_Damian.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Damian.Location = new System.Drawing.Point(1428, 710);
            this.lbl_Damian.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Damian.Name = "lbl_Damian";
            this.lbl_Damian.Size = new System.Drawing.Size(103, 31);
            this.lbl_Damian.TabIndex = 8;
            this.lbl_Damian.Text = "Damian";
            // 
            // lbl_juanra
            // 
            this.lbl_juanra.AutoSize = true;
            this.lbl_juanra.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_juanra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_juanra.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_juanra.Location = new System.Drawing.Point(734, 710);
            this.lbl_juanra.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_juanra.Name = "lbl_juanra";
            this.lbl_juanra.Size = new System.Drawing.Size(93, 31);
            this.lbl_juanra.TabIndex = 9;
            this.lbl_juanra.Text = "Juanra";
            // 
            // vida_juanra
            // 
            this.vida_juanra.BackColor = System.Drawing.SystemColors.HighlightText;
            this.vida_juanra.Location = new System.Drawing.Point(738, 861);
            this.vida_juanra.Margin = new System.Windows.Forms.Padding(4);
            this.vida_juanra.Name = "vida_juanra";
            this.vida_juanra.Size = new System.Drawing.Size(133, 28);
            this.vida_juanra.TabIndex = 10;
            this.vida_juanra.Value = 100;
            // 
            // vida_vega
            // 
            this.vida_vega.Location = new System.Drawing.Point(1052, 389);
            this.vida_vega.Margin = new System.Windows.Forms.Padding(4);
            this.vida_vega.Name = "vida_vega";
            this.vida_vega.Size = new System.Drawing.Size(133, 28);
            this.vida_vega.TabIndex = 11;
            this.vida_vega.Value = 100;
            // 
            // vida_adri
            // 
            this.vida_adri.Location = new System.Drawing.Point(516, 587);
            this.vida_adri.Margin = new System.Windows.Forms.Padding(4);
            this.vida_adri.Name = "vida_adri";
            this.vida_adri.Size = new System.Drawing.Size(133, 28);
            this.vida_adri.TabIndex = 12;
            this.vida_adri.Value = 100;
            // 
            // vida_damian
            // 
            this.vida_damian.Location = new System.Drawing.Point(1432, 861);
            this.vida_damian.Margin = new System.Windows.Forms.Padding(4);
            this.vida_damian.Name = "vida_damian";
            this.vida_damian.Size = new System.Drawing.Size(133, 28);
            this.vida_damian.TabIndex = 13;
            this.vida_damian.Value = 100;
            // 
            // vida_harillo
            // 
            this.vida_harillo.Location = new System.Drawing.Point(1677, 587);
            this.vida_harillo.Margin = new System.Windows.Forms.Padding(4);
            this.vida_harillo.Name = "vida_harillo";
            this.vida_harillo.Size = new System.Drawing.Size(133, 28);
            this.vida_harillo.TabIndex = 14;
            this.vida_harillo.Value = 100;
            // 
            // lbl_evento
            // 
            this.lbl_evento.AutoSize = true;
            this.lbl_evento.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_evento.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_evento.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_evento.Location = new System.Drawing.Point(766, 470);
            this.lbl_evento.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_evento.Name = "lbl_evento";
            this.lbl_evento.Size = new System.Drawing.Size(322, 20);
            this.lbl_evento.TabIndex = 15;
            this.lbl_evento.Text = "Comienza eligiendo movimiento Vega";
            // 
            // txt_eleccion
            // 
            this.txt_eleccion.BackColor = System.Drawing.SystemColors.Info;
            this.txt_eleccion.ForeColor = System.Drawing.SystemColors.Info;
            this.txt_eleccion.Location = new System.Drawing.Point(381, 716);
            this.txt_eleccion.Margin = new System.Windows.Forms.Padding(4);
            this.txt_eleccion.Name = "txt_eleccion";
            this.txt_eleccion.Size = new System.Drawing.Size(56, 22);
            this.txt_eleccion.TabIndex = 16;
            // 
            // btn_ok
            // 
            this.btn_ok.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_ok.Location = new System.Drawing.Point(381, 775);
            this.btn_ok.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(100, 28);
            this.btn_ok.TabIndex = 17;
            this.btn_ok.Text = "OK";
            this.btn_ok.UseVisualStyleBackColor = false;
            this.btn_ok.Click += new System.EventHandler(this.OK_Click);
            // 
            // img_harillo
            // 
            this.img_harillo.Image = global::Potatores.Properties.Resources.harillo;
            this.img_harillo.Location = new System.Drawing.Point(1677, 470);
            this.img_harillo.Margin = new System.Windows.Forms.Padding(4);
            this.img_harillo.Name = "img_harillo";
            this.img_harillo.Size = new System.Drawing.Size(133, 110);
            this.img_harillo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.img_harillo.TabIndex = 4;
            this.img_harillo.TabStop = false;
            // 
            // img_juanra
            // 
            this.img_juanra.Image = global::Potatores.Properties.Resources.juanra2;
            this.img_juanra.Location = new System.Drawing.Point(738, 746);
            this.img_juanra.Margin = new System.Windows.Forms.Padding(4);
            this.img_juanra.Name = "img_juanra";
            this.img_juanra.Size = new System.Drawing.Size(133, 108);
            this.img_juanra.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.img_juanra.TabIndex = 3;
            this.img_juanra.TabStop = false;
            // 
            // img_vega
            // 
            this.img_vega.Image = global::Potatores.Properties.Resources.vega;
            this.img_vega.Location = new System.Drawing.Point(1052, 268);
            this.img_vega.Margin = new System.Windows.Forms.Padding(4);
            this.img_vega.Name = "img_vega";
            this.img_vega.Size = new System.Drawing.Size(133, 113);
            this.img_vega.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.img_vega.TabIndex = 2;
            this.img_vega.TabStop = false;
            // 
            // img_damian
            // 
            this.img_damian.Image = global::Potatores.Properties.Resources.damian;
            this.img_damian.Location = new System.Drawing.Point(1432, 746);
            this.img_damian.Margin = new System.Windows.Forms.Padding(4);
            this.img_damian.Name = "img_damian";
            this.img_damian.Size = new System.Drawing.Size(133, 108);
            this.img_damian.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.img_damian.TabIndex = 1;
            this.img_damian.TabStop = false;
            // 
            // img_adri
            // 
            this.img_adri.Image = global::Potatores.Properties.Resources.adi;
            this.img_adri.Location = new System.Drawing.Point(516, 470);
            this.img_adri.Margin = new System.Windows.Forms.Padding(4);
            this.img_adri.Name = "img_adri";
            this.img_adri.Size = new System.Drawing.Size(133, 110);
            this.img_adri.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.img_adri.TabIndex = 0;
            this.img_adri.TabStop = false;
            // 
            // ventana
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BackgroundImage = global::Potatores.Properties.Resources.cartoon_game_temple_background_stone_battleground_free_vector;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.btn_ok);
            this.Controls.Add(this.txt_eleccion);
            this.Controls.Add(this.lbl_evento);
            this.Controls.Add(this.vida_harillo);
            this.Controls.Add(this.vida_damian);
            this.Controls.Add(this.vida_adri);
            this.Controls.Add(this.vida_vega);
            this.Controls.Add(this.vida_juanra);
            this.Controls.Add(this.lbl_juanra);
            this.Controls.Add(this.lbl_Damian);
            this.Controls.Add(this.lbl_harillo);
            this.Controls.Add(this.lbl_adri);
            this.Controls.Add(this.lbl_vega);
            this.Controls.Add(this.img_harillo);
            this.Controls.Add(this.img_juanra);
            this.Controls.Add(this.img_vega);
            this.Controls.Add(this.img_damian);
            this.Controls.Add(this.img_adri);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ventana";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lucha de Potatores";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.img_harillo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_juanra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_vega)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_damian)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_adri)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox img_adri;
        private System.Windows.Forms.PictureBox img_damian;
        private System.Windows.Forms.PictureBox img_vega;
        private System.Windows.Forms.PictureBox img_juanra;
        private System.Windows.Forms.PictureBox img_harillo;
        private System.Windows.Forms.Label lbl_vega;
        private System.Windows.Forms.Label lbl_adri;
        private System.Windows.Forms.Label lbl_harillo;
        private System.Windows.Forms.Label lbl_Damian;
        private System.Windows.Forms.Label lbl_juanra;
        private System.Windows.Forms.ProgressBar vida_juanra;
        private System.Windows.Forms.ProgressBar vida_vega;
        private System.Windows.Forms.ProgressBar vida_adri;
        private System.Windows.Forms.ProgressBar vida_damian;
        private System.Windows.Forms.ProgressBar vida_harillo;
        private System.Windows.Forms.Label lbl_evento;
        private System.Windows.Forms.TextBox txt_eleccion;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.BindingSource bindingSource1;
    }
}

