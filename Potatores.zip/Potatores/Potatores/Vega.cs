﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Potatores
{
    internal class Vega : Potatores
    {

        public Vega() {
            Habilidad1 = "Culo Peludo";
            Habilidad2 = "Chupa mi veneno";
            Habilidad3 = "Capone";
            Habilidad4 = "Rayo de luz";
            Descripcionh1 = ". Os ha enseñado su ojete lleno de pelos, os ha hecho\nsentir confusos y no habeis podido atacarle";
            Descripcionh2 = ". Se ha protegido con un manto toxico y es posible\nque os hayais causado daño si le habeis atacado";
            Descripcionh3 = " y se ha combinado con él para soltar una paliza\nmafiosa. No afecta a Juanra que se ha defendido con el Leal";
            Descripcionh4 = ". Vega se ha puesto el traje de Iron Man\n y os lanza rayos de energia";
            pasiva = "Maestro BJJ";
            nombre = "Vega";
            DanioAcumulado = 0;
        }

        public override string seleccionMovimiento(int eleccion) {
            switch (eleccion) { 
                case 1:
                    return "Vega ha usado " + Habilidad1 + Descripcionh1;
                 case 2:
                    return "Vega ha usado " + Habilidad2 + Descripcionh2;
                case 3:
                    return "Vega ha usado " + Habilidad3 + Descripcionh3;
                case 4:
                    return "Vega ha usado " + Habilidad4 + Descripcionh4;
                default:
                    return "Vega ha escogidon una habilidad que no existe y ha perdido el turno";
            }
        }

    }
}
