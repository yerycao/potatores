﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Potatores
{
    internal abstract class Potatores
    {
        public string Habilidad1 { get; set; }
        public string Descripcionh1 { get; set; }
        public string Habilidad2 { get; set; }
        public string Descripcionh2 { get; set; }
        public string Habilidad3 { get; set; }
        public string Descripcionh3 { get; set; }
        public string Habilidad4 { get; set; }
        public string Descripcionh4 { get; set; }
        public bool acertado { get; set; }
        public string nombre { get; set; }
        public int seleccion { get; set; }
        public string pasiva { get; set; }
        public int DanioAcumulado { get; set; }

        public abstract string seleccionMovimiento(int eleccion);
    }
}
