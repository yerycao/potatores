﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Potatores
{
    internal class Adri : Potatores
    {

        public Adri()
        {
            Habilidad1 = "conduccion temeraria";
            Habilidad2 = "puñalada trapera";
            Habilidad3 = "Llamada gitana";
            Habilidad4 = "Pico taladro";
            Descripcionh1 = ". Adri ha previsto vuestros ataques y se ha escapado\nrapidamente haciendo unos trompos";
            Descripcionh2 = ". Ha esquivado vuestro ataque y os ha asestado una\npuñalada por la espalda";
            Descripcionh3 = ". Adri ha llamado a toda su familia para daros\nuna paliza gitana. No afecta a Juanra, que ha llamado\nal Isaac y al Abel para defenderse";
            Descripcionh4 = " y os ha asestado un potente picotazo con la napia";
            pasiva = "Igualdad";
            nombre = "Adri";
            DanioAcumulado = 0;
        }

        public override string seleccionMovimiento(int eleccion)
        {
            switch (eleccion)
            {
                case 1:
                    return "Adri ha usado " + Habilidad1 + Descripcionh1;
                case 2:
                    return "Adri ha usado " + Habilidad2 + Descripcionh2;
                case 3:
                    return "Adri ha usado " + Habilidad3 + Descripcionh3;
                case 4:
                    return "Adri ha usado " + Habilidad4 + Descripcionh4;
                default:
                    return "Adri ha escogidon una habilidad que no existe y ha perdido el turno";
            }
        }
    }
}
