﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Potatores
{
    public partial class ventana : Form
    {

        public int turno { get; set; }
        public int eleccion { get; set; }
        public int seleccionVega { get; set; }
        public int seleccionHarillo { get; set; }
        public int seleccionDamian { get; set; }
        public int seleccionJuanra { get; set; }
        public int seleccionAdri { get; set; }

        private List<Potatores> potatores { get; set; } = new List<Potatores>();
        private Vega vega = new Vega();
        private Harillo harillo = new Harillo();
        private Damian damian = new Damian();
        private Juanra juanra = new Juanra();
        private Adri adri = new Adri();
        public Random random = new Random();
        public int aleatorio;
        public ventana()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;
            turno = 0;
            potatores.Add(vega);
            potatores.Add(harillo);
            potatores.Add(damian);
            potatores.Add(juanra);
            potatores.Add(adri);
            SoundPlayer player = new SoundPlayer("C:\\Users\\yeray\\Downloads\\combate.wav");
            player.PlayLooping();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void lbl_evento_setText(string evento)
        {
            lbl_evento.Text = evento;
        }

        // metodo para asignar la eleccion de cada jugador cuando se hace click en el boton
        public async void OK_Click(object sender, EventArgs e)
        {

            this.eleccion = int.Parse(txt_eleccion.Text);

            potatores[this.turno].seleccion = eleccion;

            this.turno++;

            txt_eleccion.Text = "";

            if (this.turno >= potatores.Count())
                await desarrollo(this.turno);
            else 
                setTurno(this.turno);
        }

        // comprueba cuantos jugadores han elegido movimiento y si estan todos muestra el movimiento de cada uno
        public async Task desarrollo(int turno) {

            for (int i = 0; i < potatores.Count(); i++)
            {
                if (potatores[i].seleccion == 3 || potatores[i].seleccion == 1)
                    await MostrarMovimiento(potatores[i].seleccionMovimiento(potatores[i].seleccion));

                else if (potatores[i].seleccion == 4)
                {
                    aleatorio = random.Next(1, 11);

                    if (aleatorio >= 1 && aleatorio <= 7)
                    {
                        potatores[i].acertado = true;
                        await MostrarMovimiento(potatores[i].seleccionMovimiento(potatores[i].seleccion));
                    }
                    else
                    {
                        potatores[i].acertado = false;
                        await MostrarMovimiento(potatores[i].nombre + " ha usado " + potatores[i].Habilidad4 + ", pero ha fallado");
                    }
                }
                else if (potatores[i].seleccion == 2)
                {
                    aleatorio = random.Next(1, 3);

                    if (aleatorio == 1)
                    {
                        potatores[i].acertado = true;
                        await MostrarMovimiento(potatores[i].seleccionMovimiento(potatores[i].seleccion));
                    }
                    else
                    {
                        potatores[i].acertado = false;
                        await MostrarMovimiento(potatores[i].nombre + " ha usado " + potatores[i].Habilidad2 + ", pero ha fallado");
                    }
                }
                else
                    await MostrarMovimiento(potatores[i].seleccionMovimiento(potatores[i].seleccion));
            }

            comprobarMovimientos();

            comprobarDanios();

            if (potatores.Count() == 1)
                SetLabelText(potatores[0].nombre + " ha ganado el combate!");
            else
            {

                for (int i = 0; i < potatores.Count(); i++)
                {
                    potatores[i].DanioAcumulado = 0;
                }

                this.turno = 0;

                setTurno(this.turno);
            }
        }

        private async Task MostrarMovimiento(string movimiento) 
        {
            SetLabelText(movimiento);
            await Task.Delay(10000);
        }

        public void setTurno(int turno) {
            
            lbl_evento_setText("Turno de " + potatores[this.turno].nombre + "\n\n1. " + potatores[this.turno].Habilidad1 + "     2. " + potatores[turno].Habilidad2 +
                "\n\n3. " + potatores[this.turno].Habilidad3 + "     4. " + potatores[turno].Habilidad4);
        }

        public void comprobarMovimientos()
        {
            if (vega.seleccion == 3)
            {
                harillo.DanioAcumulado += 10; damian.DanioAcumulado += 10; adri.DanioAcumulado += 10;
            }

            if (vega.seleccion == 4 && vega.acertado) 
            {
                harillo.DanioAcumulado += 20; damian.DanioAcumulado += 20; juanra.DanioAcumulado += 20; adri.DanioAcumulado += 20;
            }
            if (harillo.seleccion == 3)
            {
                vega.DanioAcumulado += 10; juanra.DanioAcumulado += 10; adri.DanioAcumulado += 10;
            }
            if (harillo.seleccion == 4 && harillo.acertado)
            {
                vega.DanioAcumulado += 20; damian.DanioAcumulado += 20; juanra.DanioAcumulado += 20; adri.DanioAcumulado += 20;
            }
            if (damian.seleccion == 3)
            {
                harillo.DanioAcumulado += 10; vega.DanioAcumulado += 10; juanra.DanioAcumulado += 20; adri.DanioAcumulado += 10;
            }
            if (damian.seleccion == 4 && damian.acertado)
            {
                harillo.DanioAcumulado += 20; juanra.DanioAcumulado += 20; adri.DanioAcumulado += 20;
            }
            if (juanra.seleccion == 3)
            {
                damian.DanioAcumulado += 10; vega.DanioAcumulado += 10; adri.DanioAcumulado += 10;
            }
            if (juanra.seleccion == 4 && juanra.acertado)
            {
                harillo.DanioAcumulado += 20; damian.DanioAcumulado += 20; adri.DanioAcumulado += 20;
            }
            if (adri.seleccion == 3)
            {
                harillo.DanioAcumulado += 10; damian.DanioAcumulado += 10; vega.DanioAcumulado += 10;
            }
            if (adri.seleccion == 4 && adri.acertado)
            {
                harillo.DanioAcumulado += 20; damian.DanioAcumulado += 20; juanra.DanioAcumulado += 20; vega.DanioAcumulado += 20;
            }
            if (vega.seleccion == 1) 
            {
                vega.DanioAcumulado = 0;
            }
            if (vega.seleccion == 2 && vega.acertado) 
            {
                vega.DanioAcumulado = 0;
                if (harillo.seleccion == 3 || (harillo.seleccion == 4 && harillo.acertado))
                    harillo.DanioAcumulado += 5;
                if (damian.seleccion == 3 || (damian.seleccion == 4 && damian.acertado))
                    damian.DanioAcumulado += 5;
                if (juanra.seleccion == 3 || (juanra.seleccion == 4 && juanra.acertado))
                    juanra.DanioAcumulado += 5;
                if (adri.seleccion == 3 || (adri.seleccion == 4 && adri.acertado))
                    adri.DanioAcumulado += 5;
            }
            if (harillo.seleccion == 1)
            {
                harillo.DanioAcumulado = 0;
            }
            if (harillo.seleccion == 2 && harillo.acertado)
            {
                harillo.DanioAcumulado = 0;
                if (vega.seleccion == 3 || (vega.seleccion == 4 && vega.acertado))
                    vega.DanioAcumulado += 5;
                if (damian.seleccion == 3 || (damian.seleccion == 4 && damian.acertado))
                    damian.DanioAcumulado += 5;
                if (juanra.seleccion == 3 || (juanra.seleccion == 4 && juanra.acertado))
                    juanra.DanioAcumulado += 5;
                if (adri.seleccion == 3 || (adri.seleccion == 4 && adri.acertado))
                    adri.DanioAcumulado += 5;
            }
            if (damian.seleccion == 1)
            {
                damian.DanioAcumulado = 0;
            }
            if (damian.seleccion == 2 && damian.acertado)
            {
                damian.DanioAcumulado = 0;
                if (harillo.seleccion == 3 || (harillo.seleccion == 4 && harillo.acertado))
                    harillo.DanioAcumulado += 5;
                if (vega.seleccion == 3 || (vega.seleccion == 4 && vega.acertado))
                    vega.DanioAcumulado += 5;
                if (juanra.seleccion == 3 || (juanra.seleccion == 4 && juanra.acertado))
                    juanra.DanioAcumulado += 5;
                if (adri.seleccion == 3 || (adri.seleccion == 4 && adri.acertado))
                    adri.DanioAcumulado += 5;
            }
            if (juanra.seleccion == 1)
            {
                juanra.DanioAcumulado = 0;
            }
            if (juanra.seleccion == 2 && juanra.acertado)
            {
                juanra.DanioAcumulado = 0;
                if (harillo.seleccion == 3 || (harillo.seleccion == 4 && harillo.acertado))
                    harillo.DanioAcumulado += 5;
                if (damian.seleccion == 3 || (damian.seleccion == 4 && damian.acertado))
                    damian.DanioAcumulado += 5;
                if (vega.seleccion == 3 || (vega.seleccion == 4 && vega.acertado))
                    vega.DanioAcumulado += 5;
                if (adri.seleccion == 3 || (adri.seleccion == 4 && adri.acertado))
                    adri.DanioAcumulado += 5;
            }
            if (adri.seleccion == 1)
            {
                adri.DanioAcumulado = 0;
            }
            if (adri.seleccion == 2 && adri.acertado)
            {
                adri.DanioAcumulado = 0;
                if (harillo.seleccion == 3 || (harillo.seleccion == 4 && harillo.acertado))
                    harillo.DanioAcumulado += 5;
                if (damian.seleccion == 3 || (damian.seleccion == 4 && damian.acertado))
                    damian.DanioAcumulado += 5;
                if (juanra.seleccion == 3 || (juanra.seleccion == 4 && juanra.acertado))
                    juanra.DanioAcumulado += 5;
                if (vega.seleccion == 3 || (vega.seleccion == 4 && vega.acertado))
                    vega.DanioAcumulado += 5;
            }
        }

        public void comprobarDanios() 
        {
            if ((vida_vega.Value - vega.DanioAcumulado) < 0)
                vida_vega.Value = 0;
            else
                vida_vega.Value = vida_vega.Value - vega.DanioAcumulado;
            if ((vida_harillo.Value - harillo.DanioAcumulado) < 0)
                vida_harillo.Value = 0;
            else
                vida_harillo.Value = vida_harillo.Value - harillo.DanioAcumulado;
            if ((vida_juanra.Value - juanra.DanioAcumulado) < 0)
                vida_juanra.Value = 0;
            else
                vida_juanra.Value = vida_juanra.Value - juanra.DanioAcumulado;
            if ((vida_damian.Value - damian.DanioAcumulado) < 0)
                vida_damian.Value = 0;
            else
                vida_damian.Value = vida_damian.Value - damian.DanioAcumulado;
            if ((vida_adri.Value - adri.DanioAcumulado) < 0)
                vida_adri.Value = 0;
            else
                vida_adri.Value = vida_adri.Value - adri.DanioAcumulado;

            if (vida_vega.Value == 0)
                potatores.Remove(vega);
            if (vida_harillo.Value == 0)
                potatores.Remove(harillo);
            if (vida_damian.Value == 0)
                potatores.Remove(damian);
            if (vida_juanra.Value == 0)
                potatores.Remove(juanra);
            if (vida_adri.Value == 0)
                potatores.Remove(adri);
        }
        private void SetLabelText(string evento)
        {
            lbl_evento.Text = evento;
        }
    }
}
