﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Potatores
{
    internal class Harillo : Potatores
    {
        public Harillo()
        {
            Habilidad1 = "Jesucristo";
            Habilidad2 = "Ipon";
            Habilidad3 = "Martillo de Thor";
            Habilidad4 = "Servicio agresivo";
            Descripcionh1 = " y como dios que es, vuestros ataques de simple mortal no le afectan";
            Descripcionh2 = ". Harillo ha contrarrestado vuestro ataque con un ipon";
            Descripcionh3 = ". ha lanzado cual boomerang su martillo. Nada puede pararlo";
            Descripcionh4 = ". Un buen camarero tiene que tratarte con un poco de desprecio... \nO eso dice el peluca, pero se ha dejado llevar por la rabia y os ha lanzado una bandeja llena de vajilla";
            pasiva = "Defensa vikinga";
            nombre = "Harillo";
            DanioAcumulado = 0;
            debilitado = false;
        }

        public override string seleccionMovimiento(int eleccion)
        {
            switch (eleccion)
            {
                case 1:
                    return "Harillo ha usado " + Habilidad1 + Descripcionh1;
                case 2:
                    return "Harillo ha usado " + Habilidad2 + Descripcionh2;
                case 3:
                    return "Harillo ha usado " + Habilidad3 + Descripcionh3;
                case 4:
                    return "Harillo ha usado " + Habilidad4 + Descripcionh4;
                default:
                    return "Harillo ha escogidon una habilidad que no existe y ha perdido el turno";
            }
        }
    }
}
