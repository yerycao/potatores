﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Potatores
{
    internal class Harillo : Potatores
    {
        public Harillo()
        {
            Habilidad1 = "Jesucristo";
            Habilidad2 = "Ipon";
            Habilidad3 = "Servicio agresivo";
            Habilidad4 = "Martillo de Thor";
            Descripcionh1 = ", y como dios que es, vuestros ataques de simple\nmortal no le afectan.";
            Descripcionh2 = ". Harillo ha contrarrestado vuestro ataque con un\nIpon y os devuelve algo de daño";
            Descripcionh3 = ". Se ha dejado llevar por la colera y ha cogido\nuna bandeja del Tabarca llena de vajilla y os lo lanza como piedras.\nLa ira incandescente de Harillo no afecta al Dios del Fuego Damian";
            Descripcionh4 = ". ha lanzado cual boomerang su martillo.\nNada puede pararlo";
            pasiva = "Gorila";
            nombre = "Harillo";
            DanioAcumulado = 0;
        }

        public override string seleccionMovimiento(int eleccion)
        {
            switch (eleccion)
            {
                case 1:
                    return "Harillo ha usado " + Habilidad1 + Descripcionh1;
                case 2:
                    return "Harillo ha usado " + Habilidad2 + Descripcionh2;
                case 3:
                    return "Harillo ha usado " + Habilidad3 + Descripcionh3;
                case 4:
                    return "Harillo ha usado " + Habilidad4 + Descripcionh4;
                default:
                    return "Harillo ha escogidon una habilidad que no existe y ha perdido el turno";
            }
        }
    }
}
