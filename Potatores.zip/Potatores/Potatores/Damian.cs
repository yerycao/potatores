﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Potatores
{
    internal class Damian : Potatores
    {

        public Damian()
        {
            Habilidad1 = "Rey de la cachimba";
            Habilidad2 = "Adelgazamiento extremo";
            Habilidad3 = "Polla molde";
            Habilidad4 = "Panda Choke";
            Descripcionh1 = ". Se ha hecho una buena cachimbita y no\nquiere saber nada de vosotros. Esta fumando muy tranquilo";
            Descripcionh2 = ". Damian ha reducido su superficie de impacto y\nvuestros ataques se han dirigido hacia otros oponentes";
            Descripcionh3 = ". Damian se ha puesto a hacer sus famosas figuras\ncon la polla y os ha debilitado provocandoos un ataque de risa.\nEs especialmente eficaz contra Juanra";
            Descripcionh4 = ". Elegida por él mismo como su finalizacion favorita.\nOs veis afectados contra esta tecnica mortifera.\nNo afecta a Vega, Maestro BJJ";
            pasiva = "Dios del fuego";
            nombre = "Damian";
            DanioAcumulado = 0;
        }

        public override string seleccionMovimiento(int eleccion)
        {
            switch (eleccion)
            {
                case 1:
                    return "Damian ha usado " + Habilidad1 + Descripcionh1;
                case 2:
                    return "Damian ha usado " + Habilidad2 + Descripcionh2;
                case 3:
                    return "Damian ha usado " + Habilidad3 + Descripcionh3;
                case 4:
                    return "Damian ha usado " + Habilidad4 + Descripcionh4;
                default:
                    return "Damian ha escogidon una habilidad que no existe y ha perdido el turno";
            }
        }
    }
}
