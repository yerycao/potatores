﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Potatores
{
    internal class Juanra : Potatores
    {
        public Juanra()
        {
            Habilidad1 = "Dimesion paralela";
            Habilidad2 = "Escudo del capitan america";
            Habilidad3 = "Mono loco";
            Habilidad4 = "Baseball Choke";
            Descripcionh1 = ". Se ha disuadido de la realidad que le rodea\ny ha podido regenerar algo de salud";
            Descripcionh2 = ". Todos vuestros ataques se ven repelidos\ny han rebotado contra vosotros";
            Descripcionh3 = ". Os ha visto cara de lata de cerveza y se\nha puesto a pegar cabezazos a diestro y siniestro. Ataques\nde Mono ineficaces contra el Gorila Harillo";
            Descripcionh4 = ". Es un duro gole fisico. No afecta a Vega, Maestro BJJ";
            pasiva = "Familia Cuesta";
            nombre = "Juanra";
            DanioAcumulado = 0;
        }

        public override string seleccionMovimiento(int eleccion)
        {
            switch (eleccion)
            {
                case 1:
                    return "jaunra ha usado " + Habilidad1 + Descripcionh1;
                case 2:
                    return "Juanra ha usado " + Habilidad2 + Descripcionh2;
                case 3:
                    return "Jaunra ha usado " + Habilidad3 + Descripcionh3;
                case 4:
                    return "Juanra ha usado " + Habilidad4 + Descripcionh4;
                default:
                    return "Juanra ha escogidon una habilidad que no existe y ha perdido el turno";
            }
        }
    }
}
