﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Potatores
{
    public partial class ventana : Form
    {

        public int turno { get; set; }
        public int eleccion { get; set; }
        public int seleccionVega { get; set; }
        public int seleccionHarillo { get; set; }
        public int seleccionDamian { get; set; }
        public int seleccionJuanra { get; set; }
        public int seleccionAdri { get; set; }

        private List<Potatores> potatores { get; set; } = new List<Potatores>();
        private Vega vega = new Vega();
        private Harillo harillo = new Harillo();
        private Damian damian = new Damian();
        private Juanra juanra = new Juanra();
        private Adri adri = new Adri();
        public int contador = 0;
        public Random random = new Random();
        public int aleatorio;
        public ventana()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;
            turno = 0;
            potatores.Add(vega);
            potatores.Add(harillo);
            potatores.Add(damian);
            potatores.Add(juanra);
            potatores.Add(adri);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void lbl_evento_setText(string evento)
        {
            lbl_evento.Text = evento;
        }

        // metodo para asignar la eleccion de cada jugador cuando se hace click en el boton
        public async void OK_Click(object sender, EventArgs e)
        {

            this.eleccion = int.Parse(txt_eleccion.Text);

            potatores[this.turno].seleccion = eleccion;

            this.turno++;

            txt_eleccion.Text = "";

            if (this.turno >= potatores.Count())
                await desarrollo(this.turno);
            else 
                setTurno(this.turno);
        }

        // comprueba cuantos jugadores han elegido movimiento y si estan todos muestra el movimiento de cada uno
        public async Task desarrollo(int turno) {

                for (int i = 0; i < potatores.Count(); i++)
                {
                    await MostrarMovimiento(potatores[i].seleccionMovimiento(potatores[i].seleccion));
                }

                comprobarMovimientos();

                await Task.Delay(2000);

                comprobarDanios();

                this.turno = 0;

                setTurno(this.turno);
            }

        private async Task MostrarMovimiento(string movimiento) 
        {
            SetLabelText(movimiento);
            await Task.Delay(4500);
        }

        public void setTurno(int turno) {
            
            lbl_evento_setText("Turno de " + potatores[this.turno].nombre + "\n\n1. " + potatores[this.turno].Habilidad1 + "     2. " + potatores[turno].Habilidad2 +
                "\n\n3. " + potatores[this.turno].Habilidad3 + "     4. " + potatores[turno].Habilidad4);
        }

        public void comprobarMovimientos()
        {
            if (vega.seleccion == 3) 
            {
                harillo.DanioAcumulado = 10; damian.DanioAcumulado = 10; juanra.DanioAcumulado = 10; adri.DanioAcumulado = 10;
            }
        }

        public void comprobarDanios() 
        {
            if (vega.DanioAcumulado >= 100)
            {
                vida_vega.Value = 0;
                vega.debilitado = true;
            }
            else
                vida_vega.Value = 100 - vega.DanioAcumulado;
            if (harillo.DanioAcumulado >= 100)
            {
                vida_harillo.Value = 0;
                harillo.debilitado = true;
            }
            else
                vida_harillo.Value = 100 - harillo.DanioAcumulado;
            if (damian.DanioAcumulado >= 100)
            {
                vida_damian.Value = 0;
                damian.debilitado = true;
            }
            else
                vida_damian.Value = 100 - damian.DanioAcumulado;
            if (juanra.DanioAcumulado >= 100)
            {
                vida_juanra.Value = 0;
                juanra.debilitado = true;
            }
            else
                vida_juanra.Value = 100 - juanra.DanioAcumulado;
            if (adri.DanioAcumulado >= 100)
            {
                vida_adri.Value = 0;
                adri.debilitado = true;
            }
            else
                vida_adri.Value = 100 - adri.DanioAcumulado;

            for (int i = 0; potatores.Count > 0; i++)
            {
                if (potatores[i].debilitado == true)
                    potatores.Remove(potatores[i]);
            }
        }
        private void SetLabelText(string evento)
        {
            lbl_evento.Text = evento;
        }
    }
}
